create definer = root@`%` trigger tri_update_accoun_point
    after INSERT
    on pointlog
    for each row
begin
if new.operate_type=0 then
update account set account.point = account.point - new.operate_point where account.qq_id = new.operated_qq_id;
end if;
if new.operate_type=1 then
update account set account.point = account.point + new.operate_point where account.qq_id = new.operated_qq_id;
end if;
if new.operate_type=2 then
update account set account.point = account.point - new.operate_point where account.qq_id = new.operated_qq_id;
end if;
if new.operate_type=3 then
update account set account.point = account.point - new.operate_point where account.qq_id = new.operated_qq_id;
end if;
end;

