create definer = root@`%` trigger tri_add_account
    after INSERT
    on signon
    for each row
begin
    insert into account (qq_id, point, state, create_time) values (new.qq, 0, 0, current_timestamp);
end;

